"""Telegram update handlers and conversation logic for SOHAM."""

import html
import logging
import random
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler

from bot import states, ui
from core import excel_manager, file_manager, security

logger = logging.getLogger(__name__)

NAMES = [
    "Norah", "Michael", "Camille", "Alessia", "Wayne", "Drake", "Wilson",
    "Scarlette", "Gracelyn", "Tucker", "Harmony", "Thatcher", "Melany", "Tru",
    "Freyja", "Javier", "Londyn", "Maurice", "Aubrielle", "Gustavo", "Armani",
    "Adonis", "Rebekah", "Alec", "Finley", "Santino", "Jaliyah", "Miles",
    "Teresa", "Greyson", "Amalia", "Foster", "Nathanael", "Halle", "John",
    "Trinity", "Aarav", "Elodie", "Vicente", "Maeve", "Gage", "Rachel",
    "Marcus", "Kimora", "Valentin", "Daisy", "Garrett", "Charlotte", "Leighton",
    "Makenna", "Alistair", "Cali", "Jeffery", "Nadia", "Duncan", "Brynleigh",
    "Ibrahim",
]

SURNAMES = [
    "Watson", "McConnell", "Coleman", "Nelson", "Scott", "Henderson", "Warner",
    "Weaver", "Robertson", "Quintero", "Abbott", "Nielsen", "Burch", "Maldonado",
    "Mendez", "Raymond", "Bartlett", "Mathis", "Camacho", "Berry", "McIntyre",
    "Arias", "Arnold", "Newton", "Collins", "Guevara", "Watson", "Wilkins",
    "McPherson", "Felix", "Beard", "Medrano", "Clark", "Richards", "Vincent",
    "Brennan", "Cordova", "Wagner", "Franco", "Pena", "Knox", "McDonald",
    "Horton", "Brown", "Eaton", "Lin", "Andersen", "Banks", "Whitney", "Mack",
    "Landry", "McLaughlin", "Schaefer",
]


def _db(context: ContextTypes.DEFAULT_TYPE):
    return context.bot_data["db"]


def _random_identity() -> tuple:
    return random.choice(NAMES), random.choice(SURNAMES)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Entry point: /start command."""
    await _show_main_menu(update, context)
    return states.MAIN_MENU


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Cancel the current operation and return to the main menu."""
    await _clear_session(context)
    if update.message:
        await update.message.reply_text(
            ui.success_message("Cancelled", "You can start again anytime."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
    elif update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            ui.success_message("Cancelled", "You can start again anytime."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
    return states.MAIN_MENU


async def main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Show the main menu from a callback."""
    query = update.callback_query
    if query:
        await query.answer()
    await _show_main_menu(update, context)
    return states.MAIN_MENU


async def _show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = ui.main_menu_message()
    keyboard = ui.main_menu_keyboard()
    if update.callback_query:
        await update.callback_query.edit_message_text(
            text, reply_markup=keyboard, parse_mode="HTML"
        )
    else:
        await update.message.reply_text(text, reply_markup=keyboard, parse_mode="HTML")


async def _clear_session(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clean up in-memory collection data."""
    for key in ("records", "current_file_path", "pending_uid"):
        context.user_data.pop(key, None)


# ────────────────────────────────
# Password handlers
# ────────────────────────────────
async def set_password_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        ui.set_password_prompt(),
        reply_markup=ui.back_button(),
        parse_mode="HTML",
    )
    return states.SET_PASSWORD


async def set_password_receive(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Receive and securely store the user's password."""
    password = update.message.text
    user_id = update.effective_user.id

    if not password:
        await update.message.reply_text(
            ui.error_message("Password cannot be empty. Please send a valid password."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.SET_PASSWORD

    hashed = security.hash_password(password)
    await _db(context).set_password(user_id, hashed)
    context.user_data["password_plaintext"] = password

    await update.message.reply_text(
        ui.password_saved_message(),
        reply_markup=ui.back_button(),
        parse_mode="HTML",
    )
    return states.MAIN_MENU


async def create_file_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Create New XLSX File button."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    password_hash = await _db(context).get_password_hash(user_id)
    if not password_hash:
        await query.edit_message_text(
            ui.password_required_message(),
            reply_markup=ui.password_required_keyboard(),
            parse_mode="HTML",
        )
        return states.MAIN_MENU

    plaintext = context.user_data.get("password_plaintext")
    if not plaintext:
        await query.edit_message_text(
            ui.unlock_prompt(),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.UNLOCK_PASSWORD

    return await _start_collection(update, context, plaintext)


async def unlock_password_receive(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Unlock the database with the user's password."""
    password = update.message.text
    user_id = update.effective_user.id
    password_hash = await _db(context).get_password_hash(user_id)

    if not security.verify_password(password, password_hash):
        await update.message.reply_text(
            ui.wrong_password_message(),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.UNLOCK_PASSWORD

    context.user_data["password_plaintext"] = password
    return await _start_collection(update, context, password)


# ────────────────────────────────
# Collection handlers
# ────────────────────────────────
async def _start_collection(
    update: Update, context: ContextTypes.DEFAULT_TYPE, plaintext: str
) -> int:
    """Initialize a new collection session."""
    user_id = update.effective_user.id
    context.user_data["records"] = []
    context.user_data["current_file_path"] = str(file_manager.get_new_file_path(user_id))

    name, surname = _random_identity()
    message = ui.collection_prompt(1, name, surname)
    keyboard = ui.collection_keyboard()

    if update.callback_query:
        await update.callback_query.edit_message_text(
            message, reply_markup=keyboard, parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            message, reply_markup=keyboard, parse_mode="HTML"
        )
    return states.COLLECT_UID


async def receive_uid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Receive UID and move to cookie collection."""
    uid = update.message.text.strip()
    if not uid:
        await update.message.reply_text(
            ui.error_message("UID cannot be empty. Please send a valid UID."),
            reply_markup=ui.collection_keyboard(),
            parse_mode="HTML",
        )
        return states.COLLECT_UID

    context.user_data["pending_uid"] = uid
    await update.message.reply_text(
        ui.cookies_prompt(uid),
        reply_markup=ui.collection_keyboard(),
        parse_mode="HTML",
    )
    return states.COLLECT_COOKIES


async def receive_cookies(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Receive cookies, save record, and continue collection."""
    cookies = update.message.text.strip()
    user_id = update.effective_user.id
    records = context.user_data.setdefault("records", [])
    pending_uid = context.user_data.get("pending_uid")
    plaintext = context.user_data.get("password_plaintext")

    if not pending_uid or not plaintext:
        await update.message.reply_text(
            ui.error_message("Session expired. Please start again."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.MAIN_MENU

    records.append(
        {"UID": pending_uid, "Password": plaintext, "Cookies": cookies}
    )

    current_path = Path(context.user_data["current_file_path"])
    await excel_manager.save_xlsx(records, current_path)

    entry_number = len(records)
    await update.message.reply_text(
        ui.record_saved_message(entry_number),
        reply_markup=ui.collection_keyboard(),
        parse_mode="HTML",
    )

    name, surname = _random_identity()
    await update.message.reply_text(
        ui.collection_prompt(entry_number + 1, name, surname),
        reply_markup=ui.collection_keyboard(),
        parse_mode="HTML",
    )
    context.user_data.pop("pending_uid", None)
    return states.COLLECT_UID


async def stop_collection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Finalize collection, persist metadata, and send the file."""
    query = update.callback_query
    await query.answer("Finalizing…")
    user_id = update.effective_user.id

    records = context.user_data.get("records", [])
    current_path = Path(context.user_data.get("current_file_path", ""))

    await excel_manager.save_xlsx(records, current_path)
    file_size = file_manager.get_file_size(current_path)
    filename = current_path.name

    await _db(context).create_file_record(
        user_id=user_id,
        filename=filename,
        filepath=str(current_path),
        record_count=len(records),
        file_size=file_size,
    )

    await query.edit_message_text(
        ui.stop_summary(len(records), filename, file_size, datetime.now()),
        parse_mode="HTML",
    )
    await context.bot.send_document(
        chat_id=update.effective_chat.id,
        document=open(current_path, "rb"),
        caption=f"<b>✦ SOHAM ✦</b>\nYour database is ready.",
        parse_mode="HTML",
    )

    await _clear_session(context)
    await _show_main_menu(update, context)
    return states.MAIN_MENU


async def get_current_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Send a snapshot of the current progress without stopping."""
    query = update.callback_query
    await query.answer("Generating snapshot…")
    user_id = update.effective_user.id

    records = context.user_data.get("records", [])
    current_path = Path(context.user_data.get("current_file_path", ""))

    await excel_manager.save_xlsx(records, current_path)

    snapshot_path = file_manager.get_new_file_path(user_id, prefix="Snapshot")
    await excel_manager.save_xlsx(records, snapshot_path)

    await context.bot.send_document(
        chat_id=update.effective_chat.id,
        document=open(snapshot_path, "rb"),
        caption=f"<b>✦ SOHAM Snapshot ✦</b>\nRecords so far: <code>{len(records)}</code>",
        parse_mode="HTML",
    )

    await query.edit_message_text(
        ui.snapshot_sent_message(),
        reply_markup=ui.collection_keyboard(),
        parse_mode="HTML",
    )

    pending_uid = context.user_data.get("pending_uid")
    if pending_uid:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=ui.cookies_prompt(pending_uid),
            reply_markup=ui.collection_keyboard(),
            parse_mode="HTML",
        )
        return states.COLLECT_COOKIES

    name, surname = _random_identity()
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=ui.collection_prompt(len(records) + 1, name, surname),
        reply_markup=ui.collection_keyboard(),
        parse_mode="HTML",
    )
    return states.COLLECT_UID


# ────────────────────────────────
# File management handlers
# ────────────────────────────────
async def get_files_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Display the user's saved files with download buttons."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    files = await _db(context).get_files(user_id)
    await query.edit_message_text(
        ui.files_list_message(files),
        reply_markup=ui.files_list_keyboard(files),
        parse_mode="HTML",
    )
    return states.MAIN_MENU


async def download_file_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Send a requested file to the user."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    try:
        file_id = int(query.data.split(":", 1)[1])
    except (IndexError, ValueError):
        await query.edit_message_text(
            ui.error_message("Invalid file selection."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.MAIN_MENU

    file_record = await _db(context).get_file(file_id, user_id)
    if not file_record:
        await query.edit_message_text(
            ui.error_message("File not found."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.MAIN_MENU

    path = Path(file_record["filepath"])
    if not path.exists():
        await query.edit_message_text(
            ui.error_message("File missing from storage."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.MAIN_MENU

    await context.bot.send_document(
        chat_id=update.effective_chat.id,
        document=open(path, "rb"),
        caption=f"<b>✦ SOHAM ✦</b>\n{html.escape(file_record['filename'])}",
        parse_mode="HTML",
    )
    return states.MAIN_MENU


async def delete_menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Show the delete menu."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    files = await _db(context).get_files(user_id)
    await query.edit_message_text(
        ui.delete_menu_message(files),
        reply_markup=ui.delete_menu_keyboard(files),
        parse_mode="HTML",
    )
    return states.DELETE_MENU


async def delete_file_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Ask for confirmation before deleting a specific file."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    try:
        file_id = int(query.data.split(":", 1)[1])
    except (IndexError, ValueError):
        await query.edit_message_text(
            ui.error_message("Invalid selection."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.DELETE_MENU

    file_record = await _db(context).get_file(file_id, user_id)
    if not file_record:
        await query.edit_message_text(
            ui.error_message("File not found."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
        return states.DELETE_MENU

    context.user_data["delete_target"] = file_id
    await query.edit_message_text(
        ui.delete_confirmation_message(file_record["filename"]),
        reply_markup=ui.delete_confirmation_keyboard(str(file_id)),
        parse_mode="HTML",
    )
    return states.DELETE_CONFIRM


async def delete_all_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Ask for confirmation before deleting all files."""
    query = update.callback_query
    await query.answer()
    context.user_data["delete_target"] = "all"
    await query.edit_message_text(
        ui.delete_confirmation_message(),
        reply_markup=ui.delete_confirmation_keyboard("all"),
        parse_mode="HTML",
    )
    return states.DELETE_CONFIRM


async def confirm_delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Perform the confirmed deletion."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    target = query.data.split(":", 1)[1]

    if target == "all":
        paths = await _db(context).delete_all_files(user_id)
        for path in paths:
            file_manager.delete_file(path)
        await query.edit_message_text(
            ui.success_message("🧹 All Files Deleted", "Your storage vault is now empty."),
            reply_markup=ui.back_button(),
            parse_mode="HTML",
        )
    else:
        try:
            file_id = int(target)
        except ValueError:
            await query.edit_message_text(
                ui.error_message("Invalid target."),
                reply_markup=ui.back_button(),
                parse_mode="HTML",
            )
            return states.MAIN_MENU

        path = await _db(context).delete_file(file_id, user_id)
        if path:
            file_manager.delete_file(path)
            await query.edit_message_text(
                ui.success_message("✅ File Deleted", "The selected file has been removed."),
                reply_markup=ui.back_button(),
                parse_mode="HTML",
            )
        else:
            await query.edit_message_text(
                ui.error_message("File not found."),
                reply_markup=ui.back_button(),
                parse_mode="HTML",
            )

    context.user_data.pop("delete_target", None)
    return states.MAIN_MENU


# ────────────────────────────────
# Error handlers
# ────────────────────────────────
async def error_handler(update: Optional[object], context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log errors and notify the user gracefully."""
    logger.error("Exception while handling an update:", exc_info=context.error)
    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text(
                ui.error_message("An unexpected error occurred. Please try again later."),
                reply_markup=ui.back_button(),
                parse_mode="HTML",
            )
        except Exception:
            pass
