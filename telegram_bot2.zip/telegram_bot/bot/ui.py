"""Premium UI/UX helpers for the SOHAM Telegram bot."""

import html
from datetime import datetime
from typing import List, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup


# ────────────────────────────────
# Branding
# ────────────────────────────────
SOHAM_BRAND = "✦ <b>SOHAM</b> ✦"


def _wrap(title: str, body: str) -> str:
    """Wrap a message with the SOHAM brand, title, and footer."""
    return (
        f"╔══════════════════════╗\n"
        f"║     {SOHAM_BRAND}      ║\n"
        f"╚══════════════════════╝\n\n"
        f"<b>✨ {html.escape(title)}</b>\n"
        f"{body}\n\n"
        f"<i>━ Powered by SOHAM ━</i>"
    )


def format_size(size_bytes: int) -> str:
    """Convert bytes to a human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    return f"{size_bytes / (1024 * 1024):.1f} MB"


# ────────────────────────────────
# Main Menu
# ────────────────────────────────
def main_menu_message() -> str:
    return _wrap(
        "Welcome to Your Secure Database",
        "Your premium private Excel database bot.\n"
        "Create, protect, and download your data with elegance.\n\n"
        "<i>Choose an option below to begin.</i>\n\n"
        "<blockquote>🔒 Every user has isolated storage.</blockquote>",
    )


def main_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("📄 Create New XLSX", callback_data="create"),
                InlineKeyboardButton("🔐 Set Password", callback_data="set_password"),
            ],
            [
                InlineKeyboardButton("📂 Get File", callback_data="get_files"),
                InlineKeyboardButton("🗑 Delete File", callback_data="delete_menu"),
            ],
        ]
    )


# ────────────────────────────────
# Password flows
# ────────────────────────────────
def password_required_message() -> str:
    return _wrap(
        "⚠️ Password Required",
        "Please set your password before creating your Excel database.",
    )


def password_required_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("🔐 Set Password", callback_data="set_password")],
            [InlineKeyboardButton("⬅️ Main Menu", callback_data="main_menu")],
        ]
    )


def set_password_prompt() -> str:
    return _wrap(
        "🔐 Set Your Password",
        "Send a password you will use to protect your database.\n\n"
        "<i>Your password is stored securely and is never shared.</i>",
    )


def password_saved_message() -> str:
    return _wrap(
        "✅ Password Saved Successfully",
        "Your private database is now protected.\n\n"
        "You can create your first Excel file whenever you are ready.",
    )


def unlock_prompt() -> str:
    return _wrap(
        "🔓 Unlock Database",
        "Please enter your password to start collecting data.",
    )


def wrong_password_message() -> str:
    return _wrap(
        "❌ Incorrect Password",
        "The password you entered does not match your stored password.\n"
        "Please try again.",
    )


# ────────────────────────────────
# Collection flow
# ────────────────────────────────
def collection_prompt(entry_number: int, name: str, surname: str) -> str:
    return _wrap(
        f"📋 New Entry #{entry_number}",
        "🎲 <b>Random Name:</b>\n"
        f"<code>{html.escape(name)}</code>\n\n"
        "🎲 <b>Random Surname:</b>\n"
        f"<code>{html.escape(surname)}</code>\n\n"
        "<i>Please send the UID for this entry.</i>",
    )


def cookies_prompt(uid: str) -> str:
    return _wrap(
        "🍪 Send Cookies",
        f"Please send the cookies for UID <code>{html.escape(uid)}</code>.",
    )


def record_saved_message(entry_number: int) -> str:
    return _wrap(
        f"✅ Record #{entry_number} Saved",
        "Your data has been written safely. Ready for the next entry.",
    )


def collection_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🛑 Stop & Save", callback_data="stop"),
                InlineKeyboardButton("📂 Get Current File", callback_data="current_file"),
            ]
        ]
    )


def stop_summary(
    total: int, filename: str, file_size: int, finished_at: datetime
) -> str:
    return _wrap(
        "🎉 Collection Complete",
        f"📊 <b>Total records saved:</b> <code>{total}</code>\n"
        f"📅 <b>Creation date:</b> <code>{finished_at.strftime('%Y-%m-%d')}</code>\n"
        f"🕒 <b>Creation time:</b> <code>{finished_at.strftime('%H:%M:%S')}</code>\n"
        f"📁 <b>Filename:</b> <code>{html.escape(filename)}</code>\n"
        f"📦 <b>File size:</b> <code>{format_size(file_size)}</code>\n\n"
        "<i>Your Excel database has been delivered.</i>",
    )


def snapshot_sent_message() -> str:
    return _wrap(
        "📂 Snapshot Delivered",
        "Your current progress has been sent.\n"
        "You can continue adding entries uninterrupted.",
    )


# ────────────────────────────────
# File management
# ────────────────────────────────
def files_list_message(files: List[dict]) -> str:
    if not files:
        return _wrap(
            "📂 Your Saved Files",
            "<i>Your vault is empty.</i>\n\n"
            "Create a new XLSX database to see your files here. 🚀",
        )

    cards = []
    for idx, file in enumerate(files, start=1):
        created = file["created_at"]
        cards.append(
            f"#{idx} <b>{html.escape(file['filename'])}</b>\n"
            f"   📅 {created.strftime('%Y-%m-%d')}  🕒 {created.strftime('%H:%M:%S')}\n"
            f"   📊 Records: {file['record_count']}  📦 {format_size(file['file_size'])}"
        )

    return _wrap(
        "📂 Your Saved Files",
        "\n\n".join(cards),
    )


def files_list_keyboard(files: List[dict]) -> InlineKeyboardMarkup:
    buttons = []
    for file in files:
        buttons.append(
            [
                InlineKeyboardButton(
                    f"⬇️ Download #{file['id']}",
                    callback_data=f"download:{file['id']}",
                )
            ]
        )
    buttons.append([InlineKeyboardButton("⬅️ Back", callback_data="main_menu")])
    return InlineKeyboardMarkup(buttons)


def delete_menu_message(files: List[dict]) -> str:
    if not files:
        return _wrap(
            "🗑 File Manager",
            "<i>Nothing to delete.</i>\n\n"
            "Your storage vault is clean and empty. 🧹",
        )

    cards = []
    for idx, file in enumerate(files, start=1):
        created = file["created_at"]
        cards.append(
            f"#{idx} <b>{html.escape(file['filename'])}</b>\n"
            f"   📅 {created.strftime('%Y-%m-%d')}  📊 Records: {file['record_count']}"
        )
    return _wrap(
        "🗑 File Manager",
        "Select a file to delete, or wipe everything at once.\n\n" + "\n\n".join(cards),
    )


def delete_menu_keyboard(files: List[dict]) -> InlineKeyboardMarkup:
    buttons = []
    if files:
        buttons.append(
            [InlineKeyboardButton("🗑 Delete All Files", callback_data="delete_all")]
        )
    for file in files:
        buttons.append(
            [
                InlineKeyboardButton(
                    f"❌ Delete #{file['id']}",
                    callback_data=f"delete_file:{file['id']}",
                )
            ]
        )
    buttons.append([InlineKeyboardButton("⬅️ Back", callback_data="main_menu")])
    return InlineKeyboardMarkup(buttons)


def delete_confirmation_message(target: Optional[str] = None) -> str:
    if target:
        body = (
            f"You are about to delete:\n"
            f"<code>{html.escape(target)}</code>\n\n"
            f"<b>This action cannot be undone.</b>"
        )
    else:
        body = (
            "You are about to delete <b>ALL</b> your files.\n\n"
            "<b>This action cannot be undone.</b>"
        )
    return _wrap("⚠️ Confirm Deletion", body)


def delete_confirmation_keyboard(target: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("✅ Yes, Delete", callback_data=f"confirm_delete:{target}"),
                InlineKeyboardButton("❌ Cancel", callback_data="delete_menu"),
            ]
        ]
    )


# ────────────────────────────────
# Generic helpers
# ────────────────────────────────
def back_button() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("⬅️ Main Menu", callback_data="main_menu")]]
    )


def error_message(text: str = "Something went wrong. Please try again.") -> str:
    return _wrap("⚠️ Oops", html.escape(text))


def success_message(title: str, body: str) -> str:
    return _wrap(title, body)
