"""SOHAM Premium Telegram Bot — entry point."""

import logging

from telegram import Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ConversationHandler,
    MessageHandler,
    filters,
)

from bot import handlers, states
from config import BOT_TOKEN, DATABASE_PATH, FILES_DIR
from core.database import Database

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


db = Database(DATABASE_PATH)


async def post_init(application: Application) -> None:
    """Prepare storage before the bot starts polling."""
    await db.init()
    FILES_DIR.mkdir(parents=True, exist_ok=True)
    application.bot_data["db"] = db


def main() -> None:
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", handlers.start)],
        states={
            states.MAIN_MENU: [
                CallbackQueryHandler(handlers.create_file_handler, pattern="^create$"),
                CallbackQueryHandler(handlers.set_password_start, pattern="^set_password$"),
                CallbackQueryHandler(handlers.get_files_handler, pattern="^get_files$"),
                CallbackQueryHandler(handlers.delete_menu_handler, pattern="^delete_menu$"),
                CallbackQueryHandler(handlers.download_file_handler, pattern="^download:\\d+$"),
                CallbackQueryHandler(handlers.main_menu, pattern="^main_menu$"),
            ],
            states.SET_PASSWORD: [
                CallbackQueryHandler(handlers.main_menu, pattern="^main_menu$"),
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, handlers.set_password_receive
                ),
            ],
            states.UNLOCK_PASSWORD: [
                CallbackQueryHandler(handlers.main_menu, pattern="^main_menu$"),
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, handlers.unlock_password_receive
                ),
            ],
            states.COLLECT_UID: [
                CallbackQueryHandler(handlers.stop_collection, pattern="^stop$"),
                CallbackQueryHandler(handlers.get_current_file, pattern="^current_file$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.receive_uid),
            ],
            states.COLLECT_COOKIES: [
                CallbackQueryHandler(handlers.stop_collection, pattern="^stop$"),
                CallbackQueryHandler(handlers.get_current_file, pattern="^current_file$"),
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, handlers.receive_cookies
                ),
            ],
            states.DELETE_MENU: [
                CallbackQueryHandler(handlers.delete_all_confirm, pattern="^delete_all$"),
                CallbackQueryHandler(
                    handlers.delete_file_confirm, pattern="^delete_file:\\d+$"
                ),
                CallbackQueryHandler(handlers.main_menu, pattern="^main_menu$"),
            ],
            states.DELETE_CONFIRM: [
                CallbackQueryHandler(
                    handlers.confirm_delete, pattern="^confirm_delete:(all|\\d+)$"
                ),
                CallbackQueryHandler(handlers.delete_menu_handler, pattern="^delete_menu$"),
            ],
        },
        fallbacks=[
            CommandHandler("start", handlers.start),
            CommandHandler("cancel", handlers.cancel),
        ],
        name="soham_conversation",
        persistent=False,
    )

    application.add_handler(conv_handler)
    application.add_error_handler(handlers.error_handler)

    logger.info("Starting SOHAM bot...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
