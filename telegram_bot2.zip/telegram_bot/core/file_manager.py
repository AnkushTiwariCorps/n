"""File system helpers for per-user Excel storage."""

import os
from datetime import datetime
from pathlib import Path

from config import FILES_DIR


def get_user_dir(user_id: int) -> Path:
    """Return (and create) the isolated directory for a Telegram user."""
    user_path = FILES_DIR / str(user_id)
    user_path.mkdir(parents=True, exist_ok=True)
    return user_path


def get_new_file_path(user_id: int, prefix: str = "Database") -> Path:
    """Generate a timestamped Excel file path for a user."""
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    return get_user_dir(user_id) / f"{prefix}_{timestamp}.xlsx"


def get_file_size(path: Path) -> int:
    """Return file size in bytes."""
    return os.path.getsize(path)


def delete_file(path: str) -> None:
    """Safely remove a file if it exists."""
    try:
        Path(path).unlink(missing_ok=True)
    except OSError:
        pass
