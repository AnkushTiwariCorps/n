"""Async SQLite persistence layer for the SOHAM bot."""

from datetime import datetime
from pathlib import Path
from typing import List, Optional

import aiosqlite


class Database:
    """Manages user accounts and file metadata."""

    def __init__(self, db_path: str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    async def init(self) -> None:
        """Create tables and enable WAL mode for better concurrency."""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA foreign_keys=ON")
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    password_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    filename TEXT NOT NULL,
                    filepath TEXT NOT NULL,
                    record_count INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    file_size INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
                )
                """
            )
            await db.commit()

    async def get_password_hash(self, user_id: int) -> Optional[str]:
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT password_hash FROM users WHERE user_id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                return row[0] if row else None

    async def set_password(self, user_id: int, password_hash: str) -> None:
        now = datetime.now().isoformat()
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT INTO users (user_id, password_hash, created_at)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    password_hash = excluded.password_hash,
                    created_at = excluded.created_at
                """,
                (user_id, password_hash, now),
            )
            await db.commit()

    async def create_file_record(
        self,
        user_id: int,
        filename: str,
        filepath: str,
        record_count: int,
        file_size: int,
    ) -> int:
        now = datetime.now().isoformat()
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                """
                INSERT INTO files (user_id, filename, filepath, record_count, created_at, file_size)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (user_id, filename, filepath, record_count, now, file_size),
            )
            file_id = cursor.lastrowid
            await cursor.close()
            await db.commit()
            return file_id

    async def get_files(self, user_id: int) -> List[dict]:
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                """
                SELECT id, filename, record_count, created_at, file_size
                FROM files
                WHERE user_id = ?
                ORDER BY id DESC
                """,
                (user_id,),
            ) as cursor:
                rows = await cursor.fetchall()
        files = []
        for row in rows:
            created = datetime.fromisoformat(row[3])
            files.append(
                {
                    "id": row[0],
                    "filename": row[1],
                    "record_count": row[2],
                    "created_at": created,
                    "file_size": row[4],
                }
            )
        return files

    async def get_file(self, file_id: int, user_id: int) -> Optional[dict]:
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT id, filename, filepath, record_count, created_at, file_size "
                "FROM files WHERE id = ? AND user_id = ?",
                (file_id, user_id),
            ) as cursor:
                row = await cursor.fetchone()
        if not row:
            return None
        return {
            "id": row[0],
            "filename": row[1],
            "filepath": row[2],
            "record_count": row[3],
            "created_at": datetime.fromisoformat(row[4]),
            "file_size": row[5],
        }

    async def delete_file(self, file_id: int, user_id: int) -> Optional[str]:
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT filepath FROM files WHERE id = ? AND user_id = ?",
                (file_id, user_id),
            ) as cursor:
                row = await cursor.fetchone()
            if not row:
                return None
            await db.execute(
                "DELETE FROM files WHERE id = ? AND user_id = ?", (file_id, user_id)
            )
            await db.commit()
            return row[0]

    async def delete_all_files(self, user_id: int) -> List[str]:
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT filepath FROM files WHERE user_id = ?", (user_id,)
            ) as cursor:
                rows = await cursor.fetchall()
            paths = [row[0] for row in rows]
            await db.execute("DELETE FROM files WHERE user_id = ?", (user_id,))
            await db.commit()
            return paths
