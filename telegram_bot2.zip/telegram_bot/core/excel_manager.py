"""Professional Excel generation powered by openpyxl."""

import asyncio
from pathlib import Path
from typing import List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


HEADER_FILL = PatternFill(start_color="4F46E5", end_color="4F46E5", fill_type="solid")
HEADER_FONT = Font(bold=True, color="FFFFFF", size=12)
DATA_FONT = Font(size=11)
BORDER = Border(
    left=Side(style="thin", color="D1D5DB"),
    right=Side(style="thin", color="D1D5DB"),
    top=Side(style="thin", color="D1D5DB"),
    bottom=Side(style="thin", color="D1D5DB"),
)
CENTER_ALIGN = Alignment(horizontal="center", vertical="center")
LEFT_ALIGN = Alignment(horizontal="left", vertical="center", wrap_text=True)


def _write_xlsx(records: List[dict], output_path: Path) -> None:
    """Synchronous helper that builds the workbook."""
    output_path.parent.mkdir(parents=True, exist_ok=True)

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Database"

    headers = ["UID", "Password", "Cookies"]
    worksheet.append(headers)

    for col_num, header in enumerate(headers, start=1):
        cell = worksheet.cell(row=1, column=col_num)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = CENTER_ALIGN
        cell.border = BORDER

    for record in records:
        worksheet.append(
            [record.get("UID", ""), record.get("Password", ""), record.get("Cookies", "")]
        )

    for row in worksheet.iter_rows(min_row=2, max_row=worksheet.max_row):
        for cell in row:
            cell.font = DATA_FONT
            cell.alignment = LEFT_ALIGN
            cell.border = BORDER

    column_widths = []
    for col in worksheet.columns:
        max_length = 0
        column = col[0].column_letter
        for cell in col:
            try:
                value_length = len(str(cell.value))
                if value_length > max_length:
                    max_length = value_length
            except Exception:
                pass
        adjusted_width = min(max_length + 4, 80)
        column_widths.append((column, max(adjusted_width, 12)))

    for column, width in column_widths:
        worksheet.column_dimensions[column].width = width

    worksheet.freeze_panes = "A2"
    worksheet.sheet_properties.tabColor = "4F46E5"

    workbook.save(output_path)


async def save_xlsx(records: List[dict], output_path: Path) -> None:
    """Async wrapper to avoid blocking the event loop."""
    await asyncio.to_thread(_write_xlsx, records, output_path)
