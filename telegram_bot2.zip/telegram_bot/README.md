# ✦ SOHAM ✦ Premium Telegram Excel Database Bot

A production-ready, beautifully designed Telegram bot that gives every user a **private, password-protected Excel (.xlsx) database**.

Built with **Python**, **python-telegram-bot**, **openpyxl**, and **SQLite**.

---

## 🚀 Features

- 🔐 **Password-protected** per-user database
- 📄 **Create professionally formatted Excel files** on the fly
- 🎲 **Random name/surname suggestions** for every entry
- 🔄 **Continuous collection mode** until you stop
- 📂 **Download** current or saved files anytime
- 🗑 **Delete individual files** or wipe everything with confirmation
- 💾 **Persistent SQLite storage** — survives restarts
- ⚡ **Fully async** for high concurrency
- 🎨 **Premium UI/UX** with branded headers, footers, emojis, and inline keyboards

---

## 📁 Project Structure

```
telegram_bot/
├── bot/
│   ├── __init__.py
│   ├── handlers.py      # All Telegram handlers & conversation flow
│   ├── states.py        # Conversation states
│   └── ui.py            # Premium UI messages & keyboards
├── core/
│   ├── __init__.py
│   ├── database.py      # Async SQLite persistence
│   ├── excel_manager.py # openpyxl Excel generation & styling
│   ├── file_manager.py  # Per-user file system helpers
│   └── security.py      # bcrypt password hashing
├── data/                # SQLite database
├── files/               # Generated Excel files (per user)
├── logs/                # Optional log files
├── .env.example         # Environment variable template
├── config.py            # Configuration loader
├── main.py              # Bot entry point
├── requirements.txt     # Python dependencies
└── README.md            # This file
```

---

## 🛠 Installation

### 1. Clone or extract the project

```bash
cd telegram_bot
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and set your `BOT_TOKEN` from [@BotFather](https://t.me/BotFather):

```env
BOT_TOKEN=123456789:YOUR_BOT_TOKEN_HERE
```

---

## ▶️ Running the Bot

```bash
python main.py
```

The bot will:

1. Initialize the SQLite database
2. Create the `files/` directory
3. Start polling Telegram for messages

---

## 📱 How to Use

1. **Start** the bot with `/start`
2. **Set a password** using `🔐 Set Password`
3. Press `📄 Create New XLSX File` to begin collecting data
4. Send the **UID**, then the **cookies**
5. The bot will keep collecting entries forever
6. Use `🛑 Stop & Save` to finalize and receive your Excel file
7. Use `📂 Get Current File` to grab a snapshot without stopping
8. Manage saved files with `📂 Get File` and `🗑 Delete File`

---

## 🧾 Excel Output

Each generated `.xlsx` file includes:

- Bold, colored header row
- Auto-sized columns
- Borders on every cell
- Center-aligned headers
- Frozen first row
- Professional table styling
- Timestamped filename, e.g. `Database_2026-08-05_14-25-10.xlsx`

---

## 🔒 Security Notes

- Each Telegram user has an isolated directory under `files/<user_id>/`
- Bot passwords are hashed with **bcrypt**
- The Excel file contains the user's password as requested by the workflow; keep files private
- SQLite uses **WAL mode** for better concurrency and crash safety

---

## 🏗 Deployment

### Using `systemd` (Linux)

Create a service file at `/etc/systemd/system/soham-bot.service`:

```ini
[Unit]
Description=SOHAM Telegram Bot
After=network.target

[Service]
Type=simple
User=your-user
WorkingDirectory=/path/to/telegram_bot
Environment=PYTHONUNBUFFERED=1
ExecStart=/path/to/telegram_bot/venv/bin/python main.py
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable soham-bot
sudo systemctl start soham-bot
sudo systemctl status soham-bot
```

### Using Docker

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```

---

## 📝 Logging

Logs are written to `stderr` by default. You can redirect them:

```bash
python main.py 2>&1 | tee logs/bot.log
```

---

## 🤝 License

This project is provided as-is for commercial or personal use branded under **SOHAM**.

---

<p align="center"><b>✦ Powered by SOHAM ✦</b></p>
