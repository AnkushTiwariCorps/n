"""SOHAM Premium Telegram Bot configuration."""

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(BASE_DIR / ".env")

BASE_DIR = Path(__file__).resolve().parent

BOT_TOKEN = os.getenv("BOT_TOKEN")
DATABASE_PATH = os.getenv("DATABASE_PATH", str(BASE_DIR / "data" / "soham_bot.db"))
FILES_DIR = Path(os.getenv("FILES_DIR", str(BASE_DIR / "files")))
ADMIN_IDS = [
    int(uid.strip())
    for uid in os.getenv("ADMIN_IDS", "").split(",")
    if uid.strip().isdigit()
]

if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN is missing. Please set it in your .env file.")
